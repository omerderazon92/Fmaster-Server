class InsertFartException(Exception):
    pass


class CreateChallengeException(Exception):
    pass


class AcceptChallengeException(Exception):
    pass


class CalculateWinnerException(Exception):
    pass


class SetWinnerException(Exception):
    pass


class CreateUserException(Exception):
    pass
